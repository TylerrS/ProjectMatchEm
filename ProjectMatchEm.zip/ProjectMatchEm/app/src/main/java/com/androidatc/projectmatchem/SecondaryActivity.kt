/*
    Special thanks to:
    Karl Kaiser for the idea to assign "invisible" text to the buttons
     and objective shape, and the reference for the "for" loop (starting @ line 89)
     + text & textSize assignments in "chooseShape" function.
     Link to source video: https://youtu.be/BGvjScKcW1s?t=2185

     Professor Hammond for linking this video to me.
 */

package com.androidatc.projectmatchem

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import com.androidatc.projectmatchem.R.drawable.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

import kotlin.random.Random.Default.nextInt
import kotlinx.android.synthetic.main.activity_secondary.*

class SecondaryActivity : AppCompatActivity() {

    // Declare lateinit variables for Firebase/Firestore
    lateinit var auth: FirebaseAuth
    lateinit var appDB: FirebaseDatabase
    lateinit var appRef : DatabaseReference

    // Declare variables for Firebase/Firestore
    val db = Firebase.firestore
    val readDB = FirebaseFirestore.getInstance()

    // Declare lateinit variables
    lateinit var objectiveShape : TextView
    lateinit var startButton: Button
    lateinit var clickedButton : Button
    lateinit var circleBtn : Button
    lateinit var squareBtn : Button
    lateinit var triangleBtn : Button
    lateinit var diamondBtn : Button
    lateinit var arrowBtn : Button
    lateinit var starBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_secondary)

        appRef = Firebase.database.reference
        auth = FirebaseAuth.getInstance()

        // Declare variables & arrays
        var randomGen = 0

        var userInput = 0

        var streak = 0

        var streakRecord = 0

        objectiveShape = goalShapeView

        startButton = startGameButton

        circleBtn = buttonCircle
        squareBtn = buttonSquare
        triangleBtn = buttonTriangle
        diamondBtn = buttonDiamond
        arrowBtn = buttonArrow
        starBtn = buttonStar

        // Create an array for the shapes to be assigned after a random number's generated
        val shapesArray = arrayOf(circle, square, triangle,
            diamond, arrow, star)


        // Create an array for the buttons
        val buttonArray: Array<Button> = arrayOf(buttonCircle, buttonSquare, buttonTriangle,
            buttonDiamond, buttonArrow, buttonStar)
        // Assign a text value to each button according to its' chosen shape; this is
        //  used to identify which button the user presses later on
        for(i in 0..5){
            buttonArray[i].text = shapesArray[i].toString()
            buttonArray[i].textSize = 0.0F
        }

        // Code a function that generates a random number used to determine
        //  what shape will be assigned to the objective ImageView
        fun chooseShape(view: View) {
            var randomGen = nextInt(from = 0, until = 6)
            // Use the random integer to assign a shape to the objective ImageView
            goalShapeView.setBackgroundResource(shapesArray[randomGen])
            goalShapeView.text = shapesArray[randomGen].toString()
            goalShapeView.textSize = 0.0F
        }

        // Create a function that's called whenever the user presses a shape button.
        //fun checkInput(view:View, randomGen: Int) {
        fun checkInput(view:View) {
            // Create an intent leading to the results screen (Tertiary Activity)
            var intent = Intent(this,TertiaryActivity::class.java)

            // Use an if statement to verify if the button pressed matches the chosen
            //  shape; if it does, call "chooseShape" and add 1 to the user's streak.
            //  If not, streak is saved, game is over, and intent takes user to
            //  results screen
            if(clickedButton.text == goalShapeView.text) {
                ++streak
                // Will be edited to change depending on the "Hide streak during gameplay?"
                //  option in Preferences Activity
                currentStreakTxt.text = streak.toString()

                chooseShape(goalShapeView)
            }
            // Game over condition
            else {
                checkStreakRecord(streak, streakRecord)

                if(streak > streakRecord) {
                    streakRecord = streak
                    /*
                    appRef.child("Users").child(streak.toString())
                        .child("StreakRecord").setValue(streakRecord)

                     */
                    //val writeNewRecord = appRef.getReference
                    // (WIP) Reference the database to store the record value
                    appDB = FirebaseDatabase.getInstance()
                    appRef = appDB.getReference("Users")
                        //intent.putExtra("newRecord", "New Record!!")
                }
                //
                intent.putExtra("currentStreak", "Streak: " + currentStreakTxt.text.toString())
                intent.putExtra("recordStreak", "Record: " + streakRecord.toString())
                startActivity(intent)
            }



        }

        // Verify if the user's streak is higher than their existing record, and
        //  set it as the new record if so
        fun checkStreakRecord(userStreak: Int, currentRecord: Int): Int {
            var streak = userStreak
            var record = currentRecord
            if (streak > record){
                record = streak
                intent.putExtra("newRecord", "New Record!!")
            }

            return record
        }

        // Get the user's record streak and edit
        val streakRecordListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var dbStreakRecord = snapshot.getValue()
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        }

        startButton.setOnClickListener {
            chooseShape(objectiveShape)
        }

        circleBtn.setOnClickListener {
            clickedButton = circleBtn
            checkInput(clickedButton)
        }

        squareBtn.setOnClickListener {
            clickedButton = squareBtn
            checkInput(clickedButton)
        }

        triangleBtn.setOnClickListener {
            clickedButton = triangleBtn
            checkInput(clickedButton)
        }

        diamondBtn.setOnClickListener {
            clickedButton = diamondBtn
            checkInput(clickedButton)
        }

        arrowBtn.setOnClickListener {
            clickedButton = arrowBtn
            checkInput(clickedButton)
        }

        starBtn.setOnClickListener {
            clickedButton = starBtn
            checkInput(clickedButton)
        }



    }

    //Verify
    fun checkStreakRecord(userStreak: Int, currentRecord: Int): Int {
        var streak = userStreak
        var record = currentRecord
        if (streak > record) {
            record = streak
            intent.putExtra("newRecord", "New Record!!")
        }
        return record
    }


    /*
    data class Record(var streakRecord: Int? = null) {
        fun setNewRecord(newRecord: Int) {
            val record = Record(streakRecord)
            database.child
        }
    }


     */

    /*
    fun retrieveStreak() {
        //val source = Source.SERVER
        readDB.collection("Users").document("Data")
            .get()
            //.get(source)
            .addOnSuccessListener {
                val result: StringBuffer = StringBuffer()
                if (it.isSuccessful)
                    var streakRecord = it.result.to
            }
    }



     */

}