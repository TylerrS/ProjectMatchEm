package com.androidatc.projectmatchem

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_tertiary.*

class TertiaryActivity : AppCompatActivity() {

    // Setup Firebase/Firestone variables
    private lateinit var auth: FirebaseAuth

    val db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tertiary)

        auth = FirebaseAuth.getInstance()

        // Get the values of the user's streak at game over, their record,
        //  and display a notification telling them they've set a new record
        //  if applicable
        streakTxt.text = intent.getStringExtra("currentStreak")
        newRecordTxt.text = intent.getStringExtra("newRecord")
        currentRecordTxt.text = intent.getStringExtra("recordStreak")
    }

    /*
        Create a function that returns user back to Secondary
            Activity after pressing the "Play again?" button
     */
    fun replay(view:View) {
        val playAgain = Intent(this,SecondaryActivity::class.java)
        startActivity(playAgain)
    }

    /*
        Create a function that sends user back to main menu after
            pressing "Return to Main Menu" button
     */
    fun returnToMain(view:View) {
        var toMain = Intent(this,MainActivity::class.java)
        startActivity(toMain)
    }

    /*
    Create function to send user to help activity
        after clicking the "helpImage" ImageView
        (question mark in circle at upper-right corner of app)
     */
    fun toHelp(view:View) {
        var help = Intent(this,Help::class.java)
        startActivity(help)
    }

    /*
        Create function to send user to preferences activity
            after clicking "settingsImage" ImageView
            (gear icon near upper-right corner of app)
      */
    fun toPreferences(view:View) {
        var preferences = Intent(this,Preferences::class.java)
        startActivity(preferences)
    }
}