package com.androidatc.projectmatchem

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Help : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)
    }


    /*
        Create function to send user to preferences activity
            after clicking "settingsImage" ImageView
            (gear icon near upper-right corner of app)
     */
    fun toPreferences(view:View) {
        var preferences = Intent(this,Preferences::class.java)
        startActivity(preferences)
    }

    /*
        Create a function that sends user back to main menu after
            pressing "Return to Main Menu" button
     */
    fun returnToMain(view:View) {
        var toMain = Intent(this,MainActivity::class.java)
        startActivity(toMain)
    }
}