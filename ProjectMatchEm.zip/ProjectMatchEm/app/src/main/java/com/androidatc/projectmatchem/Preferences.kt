package com.androidatc.projectmatchem

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_preferences.*
import kotlinx.android.synthetic.main.activity_secondary.*

class Preferences : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preferences)


        hideStreakDuringGameplaySwitch.setOnClickListener {
            var intent = Intent(this,SecondaryActivity::class.java)
            if(hideStreakDuringGameplaySwitch.isChecked == true) {
                intent.putExtra("hideStreakCount", "")
            }

            else if (hideStreakDuringGameplaySwitch.isChecked == false) {
                intent.putExtra("hideStreakCount", "0")
            }



        }
    }

    /*
    Create function to send user to help activity
        after clicking the "helpImage" ImageView
        (question mark in circle at upper-right corner of app)
 */
    fun toHelp(view:View) {
        var help = Intent(this,Help::class.java)
        startActivity(help)
    }

    /*
    Create a function that sends user back to main menu after
        pressing "Return to Main Menu" button
     */
    fun returnToMain(view: View) {
        var toMain = Intent(this,MainActivity::class.java)
        startActivity(toMain)
    }
}