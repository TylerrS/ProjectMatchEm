/*
    Tyler Smekens
    5-13-22
    SDEV264
    M08 Course Project Final Submission
    Professor Hammond
 */

package com.androidatc.projectmatchem

import android.content.ContentValues.TAG
import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AlertDialog
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    // Create variables for Firebase/Firestore
    lateinit var auth: FirebaseAuth

    val db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Start authentication for Firebase
        auth = Firebase.auth


        // Sign a user in anonymously
        auth.signInAnonymously()
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Successful sign-in
                    Log.d(TAG, "signInAnonymously:success")
                    val user = auth.currentUser
                }
                else {
                    // Display a message indicating sign-in failure
                    Log.w(TAG, "signInAnonymously:failure", task.exception)
                }
            }

        // Takes user to Secondary Activity when they click the "Play!" button
        playButton.setOnClickListener {
            startActivity(Intent(this, SecondaryActivity::class.java))
        }

        // Enables cloud saving if the switch is enabled; if disabled afterwards, a
        //  warning message is included to confirm the decision
        enableCloudSavingSwitch.setOnClickListener {
            if(enableCloudSavingSwitch.isChecked == true) {
                newPlayer()
            }
            else if(enableCloudSavingSwitch.isChecked == false) {
                savingOff(enableCloudSavingSwitch)
            }

        }
        // WIP; send streak record data over to MainActivity so it's displayed on main menu
        recordTxtView.text = intent.getStringExtra("recordStreak")

    }


    // Run a function to check that the user's signed in and has a document to their ID
    public override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        val uid = currentUser?.uid
        db.collection("Users").document("Data")
            .get()
    }


    // Create a function to add player's data to the database
     private fun newPlayer() {
        val currentUser = auth.currentUser
        val uid = currentUser?.uid
        // Call the database
        val checkDB = FirebaseFirestore.getInstance()
        // Get the database-stored data, if applicable
        db.collection("Users").document("Data")
            .get()
        // Create a new data set with a streak record, UID and "Show streak" preference;
        //  "SaveEnabled" is meant to ensure the switch stays checked (WIP)
        val user = hashMapOf(
            "UID" to uid.toString(),
            "StreakRecord" to 0,
            "HideStreakPref" to false,
            "SaveEnabled" to enableCloudSavingSwitch.isChecked
        )

        // Add a new document with a generated ID
        db.collection("Users")
            .document("Data").set(user)
            .addOnSuccessListener {
                Log.d(TAG, "DocumentSnapshot added with ID: Data")
            }

    }

    // Create a function that shows a dialog box if, once the user enables cloud saving,
    //  they press the switch again, which would make it false
    fun savingOff(view: View) {
        // Create dialog box
        val disableSavingAlert = AlertDialog.Builder(this)
        disableSavingAlert.setTitle("Disable Saving")
        disableSavingAlert.setMessage("Are you sure you want to disable cloud saving? All" +
                "stored data will be deleted.")
        // Set "yes" button
        disableSavingAlert.setPositiveButton("Yes") {
            dialogInterface: DialogInterface, _: Int -> Snackbar.make(
                findViewById(R.id.enableCloudSavingSwitch),
                "Saving disabled. Data deleted.", Snackbar.LENGTH_LONG).show()
            db.collection("Users").document("Data")
                .delete()
        }
        disableSavingAlert.setNegativeButton("No") {
            dialogInterface: DialogInterface, _: Int -> Snackbar.make(
                findViewById(R.id.enableCloudSavingSwitch),
                "Changes not saved. Saving still enabled.", Snackbar.LENGTH_LONG).show()
            enableCloudSavingSwitch.isChecked = true
        }

        disableSavingAlert.show()
    }

    /*
        Create function to send user to help activity
            after clicking the "helpImage" ImageView
            (question mark in circle at upper-right corner of app)
     */
    fun toHelp(view:View) {
        var help = Intent(this,Help::class.java)
        startActivity(help)
    }

    /*
        Create function to send user to preferences activity
            after clicking "settingsImage" ImageView
            (gear icon near upper-right corner of app)
     */
    fun toPreferences(view:View) {
        var preferences = Intent(this,Preferences::class.java)
        startActivity(preferences)
    }
}